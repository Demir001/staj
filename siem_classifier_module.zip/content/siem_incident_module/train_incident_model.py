# File: train_incident_model.py
# Description: Production-Scale Training Script with Automatic Hardware Detection (CUDA GPU / CPU)
# Features: 500K Log Generation, Auto-Hardware Fallback, Model Training, Cross-Validation & Evaluation Export

import os
import time
import sys
import torch
from typing import Tuple, List, Dict, Any

from config.incident_config import config
from src.incident_dataset import SIEMIncidentDatasetGenerator
from src.incident_classifier import SIEMIncidentClassifier
from src.deep_classifier import GPUDeepSIEMClassifier
from src.evaluator import SIEMModelEvaluator


def detect_hardware() -> str:
    """
    Sistemde CUDA GPU varlığını kontrol eder ve kullanılacak donanım modunu belirler.
    """
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
        vram_gb = torch.cuda.get_device_properties(0).total_memory / 1e9
        print(f"🚀 [HARDWARE DETECTED] CUDA GPU Aktif!")
        print(f"   ├─ Cihaz Adı   : {gpu_name}")
        print(f"   ├─ Toplam VRAM : {vram_gb:.2f} GB")
        print(f"   └─ CUDA Sürümü : {torch.version.cuda}")
        return "GPU"
    else:
        cpu_cores = os.cpu_count()
        print(f"⚙️ [HARDWARE DETECTED] CUDA Bulunamadı. CPU Modu Aktif.")
        print(f"   └─ Kullanılabilir CPU Çekirdek Sayısı: {cpu_cores}")
        return "CPU"


def train_pipeline(total_logs: int = 500000, epochs: int = 5, test_split: float = 0.20):
    """
    Üretim Seviyesi Otomatik Eğitim ve Doğrulama Pipeline'ı.
    """
    start_total_time = time.time()
    config.paths.ensure_directories()

    print("\n" + "=" * 95)
    print("🛡️ ENTERPRISE SIEM INCIDENT TAXONOMY MODEL TRAINING PIPELINE")
    print("=" * 95 + "\n")

    # 1. Donanım Tespiti
    hardware_mode = detect_hardware()

    # 2. Veri Seti Üretimi
    print(f"\n📦 [STAGE 1/4] {total_logs:,} Adet SIEM Logu Sentezleniyor...")
    gen_start = time.time()
    dataset_gen = SIEMIncidentDatasetGenerator()
    raw_logs, labels = dataset_gen.build_dataset(total_logs=total_logs)
    gen_elapsed = time.time() - gen_start
    print(f"✅ Veri üretimi {gen_elapsed:.2f} saniyede tamamlandı.")

    # 3. Train / Test Ayrımı (Train-Test Split)
    print(f"\n✂️ [STAGE 2/4] Veri Kümesi Train (%{int((1-test_split)*100)}) ve Test (%{int(test_split*100)}) Olarak Ayrılıyor...")
    split_idx = int(len(raw_logs) * (1 - test_split))
    
    train_logs, test_logs = raw_logs[:split_idx], raw_logs[split_idx:]
    train_labels, test_labels = labels[:split_idx], labels[split_idx:]
    
    print(f"   ├─ Eğitim Örnek Sayısı : {len(train_logs):,}")
    print(f"   └─ Test Örnek Sayısı   : {len(test_logs):,}")

    # 4. Model Eğitimi (Donanıma Göre Otomatik Seçim)
    print(f"\n🏋️ [STAGE 3/4] {hardware_mode} Üzerinde Model Eğitimi Başlatılıyor...")
    train_start = time.time()
    
    if hardware_mode == "GPU":
        # PyTorch 1D-CNN + BiLSTM + Attention (GPU)
        model = GPUDeepSIEMClassifier(max_seq_len=256, batch_size=1024, lr=1e-3)
        model.fit(train_logs, train_labels, epochs=epochs)
        saved_model_path = os.path.join(config.paths.MODELS_DIR, "gpu_deep_incident_model.pt")
        model.save(saved_model_path)
    else:
        # Multi-Threaded Random Forest Ensemble (CPU)
        model = SIEMIncidentClassifier(n_estimators=300, max_features=12000)
        model.fit(train_logs, train_labels)
        saved_model_path = model.save(config.paths.MODEL_FILE)

    train_elapsed = time.time() - train_start
    print(f"✅ Model eğitimi {train_elapsed:.2f} saniyede tamamlandı.")

    # 5. Model Değerlendirme ve Performans Ölçümü
    print(f"\n📊 [STAGE 4/4] Test Veri Kümesi Üzerinde Performans Analizi Yapılıyor...")
    eval_start = time.time()
    
    y_pred = []
    if hardware_mode == "GPU":
        # Toplu GPU çıkarımı
        model.model.eval()
        with torch.no_grad():
            for i in range(0, len(test_logs), 1024):
                batch_logs = test_logs[i:i+1024]
                cleaned_batch = model.preprocessor.transform_batch(batch_logs)
                inputs = model.tokenizer.encode_batch(cleaned_batch).to(model.device)
                logits = model.model(inputs)
                probs = torch.softmax(logits, dim=1)
                best_indices = torch.argmax(probs, dim=1).cpu().numpy()
                y_pred.extend([model.idx_to_label[idx] for idx in best_indices])
    else:
        # Toplu CPU çıkarımı
        batch_results = model.predict_batch(test_logs)
        y_pred = [res["predicted_category"] for res in batch_results]

    eval_elapsed = time.time() - eval_start

    # Evaluator ile Raporlama
    evaluator = SIEMModelEvaluator()
    eval_summary = evaluator.evaluate_predictions(
        y_true=test_labels,
        y_pred=y_pred,
        inference_time_seconds=eval_elapsed,
        model_name=f"SIEM_{hardware_mode}_Engine"
    )

    evaluator.print_evaluation_report(eval_summary)
    evaluator.plot_confusion_matrix(eval_summary)
    evaluator.export_json_report(eval_summary)

    total_pipeline_time = time.time() - start_total_time
    print(f"🎉 TÜM EĞİTİM VE DOĞRULAMA SÜRECİ BAŞARIYLA TAMAMLANDI! (Toplam Süre: {total_pipeline_time:.2f} saniye)")


if __name__ == "__main__":
    # Parametreler: 500.000 Log, 5 Epoch (GPU için)
    train_pipeline(total_logs=500000, epochs=5, test_split=0.20)