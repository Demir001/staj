# File: config/incident_config.py
# Description: Production-Grade Configuration for SIEM Incident Taxonomy & Root Cause Model
# Architecture: Scalable, Thread-Safe, Data-Class Based Multi-Layer SIEM Configuration

import os
from dataclasses import dataclass, field
from typing import Dict, List, Any


@dataclass(frozen=True)
class PathConfig:
    """Proje dizin yapıları ve dosya yolları konfigürasyonu."""
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    DATA_DIR: str = os.path.join(BASE_DIR, "data")
    MODELS_DIR: str = os.path.join(BASE_DIR, "models")
    LOGS_DIR: str = os.path.join(BASE_DIR, "logs")
    EXPORTS_DIR: str = os.path.join(BASE_DIR, "exports")

    # Dosya Yolları
    MODEL_FILE: str = os.path.join(MODELS_DIR, "incident_taxonomy_model.joblib")
    VECTORIZER_FILE: str = os.path.join(MODELS_DIR, "incident_vectorizer.joblib")
    DATASET_CACHE_FILE: str = os.path.join(DATA_DIR, "synthetic_incident_dataset.parquet")
    EVALUATION_REPORT_FILE: str = os.path.join(LOGS_DIR, "evaluation_report.json")
    ONNX_EXPORT_FILE: str = os.path.join(EXPORTS_DIR, "incident_taxonomy_model.onnx")

    def ensure_directories(self) -> None:
        """Gerekli tüm sistem dizinlerinin varlığını garanti eder."""
        for path in [self.DATA_DIR, self.MODELS_DIR, self.LOGS_DIR, self.EXPORTS_DIR]:
            os.makedirs(path, exist_ok=True)


@dataclass(frozen=True)
class FeatureExtractionConfig:
    """N-Gram ve TF-IDF Metin İşleme Hiperparametreleri."""
    ANALYZER: str = "char_wb"              # Sözcük sınırlarında karakter bazlı N-Gram (Obfuskasyona dirençli)
    NGRAM_RANGE: tuple = (3, 5)            # 3'lü, 4'lü ve 5'li alt karakter dizilimleri
    MAX_FEATURES: int = 15000              # Büyütülmüş kelime haznesi kapasitesi
    SUBLINEAR_TF: bool = True              # Frekansı sublinear logaritmik ölçekle (1 + log(tf))
    MIN_DF: int = 2                        # En az 2 belgede geçmeyen gürültülü token'ları ele
    MAX_DF: float = 0.98                   # Belge frekansı %98'in üzerinde olan aşırı genel yapıları ele
    NORM: str = "l2"                       # Vektör normlama türü (L2-norm)
    STRIP_ACCENTS: str = "unicode"         # Aksan ve özel karakter düzenleme


@dataclass(frozen=True)
class ModelHyperparameters:
    """Random Forest ve Ensemble Model Hiperparametreleri (CPU Optimize)."""
    N_ESTIMATORS: int = 300                # Karar Ağacı Sayısı
    MAX_DEPTH: int = 35                    # Derinlik Sınırı (Overfitting Engelleme)
    MIN_SAMPLES_SPLIT: int = 4             # Düğüm bölünmesi için gereken asgari örnek sayısı
    MIN_SAMPLES_LEAF: int = 2              # Yaprak düğümde bulunması gereken asgari örnek sayısı
    CRITERION: str = "gini"                # Bölünme Kalite Ölçütü (Gini Impurity)
    CLASS_WEIGHT: str = "balanced"         # Sınıf dengesizliklerini otomatik ağırlıklandır
    N_JOBS: int = -1                       # Tüm CPU çekirdeklerini %100 kapasiteyle çalıştır
    RANDOM_STATE: int = 42                 # Tekrarlanabilir sonuçlar için sabit Seed
    VERBOSE: int = 0                       # Log çıktı detay seviyesi


@dataclass(frozen=True)
class DatasetConfig:
    """Veri Kümesi Üretim ve Senaryo Konfigürasyonu."""
    SAMPLES_PER_CATEGORY: int = 25000      # 4 Kategori x 25.000 = Total 100.000 Log
    TEST_SPLIT_RATIO: float = 0.20         # %80 Eğitim, %20 Doğrulama/Test ayrımı
    SHUFFLE_DATASET: bool = True           # Veri kümesini rastgele karıştır
    VALIDATION_FOLDS: int = 5              # 5-Fold Stratified Cross-Validation


@dataclass(frozen=True)
class TaxonomyCategoryDefinition:
    """SIEM Kök Neden ve Müdahale Rehberi (Playbook) Tanımlamaları."""
    CATEGORIES: Dict[str, Dict[str, Any]] = field(default_factory=lambda: {
        "SYSTEM_INTEGRITY": {
            "title": "Sistem Bütünlüğü & Yetki İhlali (Privilege Escalation / System Alteration)",
            "mitre_id": "T1548.003 / T1003",
            "mitre_name": "Abuse Elevation Control Mechanism: Sudo / SUID & Credential Dumping",
            "playbook": (
                "1. İlgili kullanıcı oturumunu derhal sonlandırın (pkill -KILL -u <user>).\n"
                "2. SUID/SGID izinlerini ve /etc/sudoers dosyasını varsayılan duruma getirin.\n"
                "3. /etc/pam.d/ dizinindeki PAM modüllerini ve /etc/passwd bütünlüğünü doğrulayın.\n"
                "4. Etkilenen kullanıcının tüm kimlik doğrulama anahtarlarını (SSH Keys/Passwords) değiştirin."
            ),
            "urgency": "HIGH",
            "base_risk_weight": 75.0
        },
        "NETWORK_C2": {
            "title": "Ağ Geçidi & Komuta-Kontrol Trafiği (Command & Control / Exfiltration)",
            "mitre_id": "T1059.004 / T1041",
            "mitre_name": "Command and Scripting Interpreter: Unix Shell & Exfiltration Over C2 Channel",
            "playbook": (
                "1. Hedef dış IP adresini Firewall / WAF üzerinde derhal DROP kuralıyla engelleyin.\n"
                "2. Tespiti yapılan aktif soket bağlantısını sonlandırın (ss -k veya fuser -k).\n"
                "3. Sunucu üzerindeki giden bağlantı (outbound) kurallarını kısıtlayın.\n"
                "4. Sızdırılma ihtimali olan veritabanı veya hassas dosyaların dökümünü inceleyin."
            ),
            "urgency": "CRITICAL",
            "base_risk_weight": 90.0
        },
        "PROCESS_INJECTION": {
            "title": "Sessiz Bellek & Çekirdek Anomalisi (RAM-Only / Memory Injection)",
            "mitre_id": "T1055 / T1620",
            "mitre_name": "Process Injection & Reflective Code Loading (memfd_create / ptrace)",
            "playbook": (
                "1. Hedef prosesi dondurun (kill -STOP <pid>).\n"
                "2. Adli bilişim (Forensics) için /proc/<pid>/mem ve /proc/<pid>/maps dökümünü alın.\n"
                "3. Prosesi tamamen sonlandırın (kill -9 <pid>).\n"
                "4. Çekirdek modüllerini (lsmod) kontrol edin, bpf ve kprobe kancalarını tarayın."
            ),
            "urgency": "CRITICAL",
            "base_risk_weight": 95.0
        },
        "APPLICATION_EXPLOIT": {
            "title": "Uygulama / Web Servis Zafiyeti İstismarı (Web Exploits / Service RCE)",
            "mitre_id": "T1190 / T1210",
            "mitre_name": "Exploit Public-Facing Application (SQLi / XXE / LFI / Deserialization)",
            "playbook": (
                "1. Saldırı kaynağı olan IP adresini WAF / IP-Table seviyesinde engelleyin.\n"
                "2. İstismar edilen web uygulamasını / podunu izole moda alın veya yeniden başlatın.\n"
                "3. Uygulama loglarından enjekte edilen payload'ın başarılı olup olmadığını doğrulayın.\n"
                "4. İlgili uygulama zafiyet kütüphanesini ve bağımlılıklarını güncelleyin."
            ),
            "urgency": "HIGH",
            "base_risk_weight": 80.0
        }
    })


class SIEMIncidentConfig:
    """Tüm konfigürasyon bileşenlerini bir arada tutan ana erişim sınıfı."""
    def __init__(self):
        self.paths = PathConfig()
        self.features = FeatureExtractionConfig()
        self.model = ModelHyperparameters()
        self.dataset = DatasetConfig()
        self.taxonomy = TaxonomyCategoryDefinition()
        self.paths.ensure_directories()

    def get_summary(self) -> Dict[str, Any]:
        """Konfigürasyon özetini döner."""
        return {
            "model_path": self.paths.MODEL_FILE,
            "n_estimators": self.model.N_ESTIMATORS,
            "max_features": self.features.MAX_FEATURES,
            "total_synthetic_samples": self.dataset.SAMPLES_PER_CATEGORY * 4,
            "categories": list(self.taxonomy.CATEGORIES.keys())
        }


# Global Konfigürasyon Nesnesi
config = SIEMIncidentConfig()