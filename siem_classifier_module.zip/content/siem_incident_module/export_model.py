# File: export_model.py
# Description: Production-Grade Model Exporter, ONNX Converter & Standalone SOC Artifact Bundler
# Features: PyTorch/Scikit-Learn Model Serialization, ONNX Conversion, Hash Verification & Deployment Manifest Generation

import os
import time
import json
import hashlib
import torch
import joblib
from typing import Dict, Any

from config.incident_config import config
from src.incident_classifier import SIEMIncidentClassifier
from src.deep_classifier import GPUDeepSIEMClassifier


def compute_sha256(filepath: str) -> str:
    """
    Üretim dağıtımında bütünlüğü doğrulamak için model dosyasının SHA256 özetini hesaplar.
    """
    sha256_hash = hashlib.sha256()
    with open(filepath, "rb") as f:
        for byte_block in iter(lambda: f.read(4096), b""):
            sha256_hash.update(byte_block)
    return sha256_hash.hexdigest()


def export_pytorch_to_onnx(deep_model_wrapper: GPUDeepSIEMClassifier, output_onnx_path: str) -> bool:
    """
    PyTorch Derin Öğrenme Modelini yüksek performanslı mikro-saniye çıkarım için ONNX formatına dönüştürür.
    """
    print(f"🔄 [ONNX EXPORTER] PyTorch Modeli ONNX formatına dönüştürülüyor...")
    try:
        model = deep_model_wrapper.model
        model.eval()
        model.to("cpu")  # ONNX dışa aktarımı için CPU tensörlerine taşı

        # Örnek Giriş Tensörü (Batch Size: 1, Sequence Length: 256)
        dummy_input = torch.randint(0, deep_model_wrapper.tokenizer.vocab_size, (1, 256), dtype=torch.long)

        # Dinamik Eksenler (Farklı Batch Boyutlarını Desteklemek İçin)
        dynamic_axes = {
            "input_tokens": {0: "batch_size", 1: "sequence_length"},
            "output_logits": {0: "batch_size"}
        }

        os.makedirs(os.path.dirname(output_onnx_path), exist_ok=True)

        torch.onnx.export(
            model,
            dummy_input,
            output_onnx_path,
            export_params=True,
            opset_version=14,
            do_constant_folding=True,
            input_names=["input_tokens"],
            output_names=["output_logits"],
            dynamic_axes=dynamic_axes
        )
        print(f"✅ [ONNX EXPORTER] ONNX Modeli başarıyla oluşturuldu: {output_onnx_path}")
        return True
    except Exception as e:
        print(f"⚠️ [ONNX EXPORTER] ONNX Dönüşüm Hatası: {str(e)}")
        return False


def export_pipeline_artifacts():
    """
    Tüm model bileşenlerini, konfigürasyon metadatalarını ve doğrulama anahtarlarını 
    SOC canlı sistemine kuruluma hazır 'Artifact Bundle' halinde paketler.
    """
    config.paths.ensure_directories()
    
    print("\n" + "=" * 95)
    print("📦 ENTERPRISE SIEM MODEL EXPORT & DEPLOYMENT ARTIFACT BUNDLER")
    print("=" * 95 + "\n")

    gpu_model_path = os.path.join(config.paths.MODELS_DIR, "gpu_deep_incident_model.pt")
    cpu_model_path = config.paths.MODEL_FILE
    export_dir = config.paths.EXPORTS_DIR

    artifacts_meta = {
        "export_timestamp": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()),
        "target_environment": "Production-SOC-Daemon",
        "exported_files": []
    }

    # 1. GPU Modeli Dışa Aktarma (PyTorch + ONNX)
    if os.path.exists(gpu_model_path):
        print(f"🔍 Derin Öğrenme GPU Modeli Tespit Edildi: {gpu_model_path}")
        deep_wrapper = GPUDeepSIEMClassifier.load(gpu_model_path)
        
        # SHA256 Hesapla
        model_hash = compute_sha256(gpu_model_path)
        artifacts_meta["exported_files"].append({
            "type": "PyTorch_Model_Checkpoint",
            "path": gpu_model_path,
            "sha256": model_hash
        })
        
        # ONNX Dönüştürme
        onnx_file = config.paths.ONNX_EXPORT_FILE
        if export_pytorch_to_onnx(deep_wrapper, onnx_file):
            onnx_hash = compute_sha256(onnx_file)
            artifacts_meta["exported_files"].append({
                "type": "ONNX_Runtime_Model",
                "path": onnx_file,
                "sha256": onnx_hash
            })

    # 2. CPU Modeli Dışa Aktarma (Random Forest + Joblib)
    if os.path.exists(cpu_model_path):
        print(f"🔍 Random Forest CPU Modeli Tespit Edildi: {cpu_model_path}")
        cpu_hash = compute_sha256(cpu_model_path)
        artifacts_meta["exported_files"].append({
            "type": "Scikit_Learn_Joblib_Bundle",
            "path": cpu_model_path,
            "sha256": cpu_hash
        })

    # 3. Canlı Entegrasyon Manifest Dosyasını (deployment_manifest.json) Oluşturma
    manifest_path = os.path.join(export_dir, "deployment_manifest.json")
    manifest_data = {
        "version": "2.5.0-Enterprise",
        "system_name": "SIEM_Incident_Taxonomy_Engine",
        "metadata": artifacts_meta,
        "taxonomy_definition": config.taxonomy.CATEGORIES,
        "feature_extraction": {
            "analyzer": config.features.ANALYZER,
            "ngram_range": list(config.features.NGRAM_RANGE),
            "max_features": config.features.MAX_FEATURES
        }
    }

    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest_data, f, indent=4, ensure_ascii=False)

    print(f"\n📋 [DEPLOYMENT MANIFEST] Canlı Kurulum Manifesti Kaydedildi: {manifest_path}")
    print(f"🔒 Bütünlük Doğrulama Özeti (SHA256 Manifest): {compute_sha256(manifest_path)}")
    print("\n🎉 MODEL VE BİLEŞENLERİ CANLI PROD / SOC ORTAMINA SEVK EDİLMEYE HAZIR!")


if __name__ == "__main__":
    export_pipeline_artifacts()