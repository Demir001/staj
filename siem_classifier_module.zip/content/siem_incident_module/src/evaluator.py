# File: src/evaluator.py
# Description: Enterprise Evaluation & Performance Analysis Engine for GPU/CPU SIEM Models
# Features: Multi-Class Confusion Matrix, ROC-AUC Multi-Curve Calculation, Classification Report & JSON Exporter

import os
import time
import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Any, Union, Tuple
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    precision_recall_fscore_support,
    accuracy_score,
    roc_auc_score
)

from config.incident_config import config


class SIEMModelEvaluator:
    """
    Eğitilen SIEM modellerinin (GPU PyTorch / CPU Random Forest) performansını 
    endüstriyel metriklerle (Precision, Recall, F1-Score, Confusion Matrix, Latency) 
    ölçen ve raporlayan değerlendirme motoru.
    """
    def __init__(self, class_names: List[str] = None):
        self.class_names = class_names or list(config.taxonomy.CATEGORIES.keys()) + ["SAFE_NOISE", "OBFUSCATION_EVASION"]

    def evaluate_predictions(
        self, 
        y_true: List[str], 
        y_pred: List[str], 
        inference_time_seconds: float = 0.0,
        model_name: str = "SIEM_Incident_Model"
    ) -> Dict[str, Any]:
        """
        Tahminler ile gerçek etiketleri karşılaştırarak detaylı performans analizi çıkarır.
        """
        unique_labels = sorted(list(set(y_true).union(set(y_pred))))
        
        # Temel Metrikler
        accuracy = accuracy_score(y_true, y_pred)
        precision, recall, f1, support = precision_recall_fscore_support(
            y_true, y_pred, labels=unique_labels, average=None, zero_division=0
        )
        
        macro_p, macro_r, macro_f1, _ = precision_recall_fscore_support(
            y_true, y_pred, average="macro", zero_division=0
        )
        weighted_p, weighted_r, weighted_f1, _ = precision_recall_fscore_support(
            y_true, y_pred, average="weighted", zero_division=0
        )

        # Sınıf Bazlı Detay Raporu
        class_metrics = {}
        for idx, label in enumerate(unique_labels):
            class_metrics[label] = {
                "precision": round(float(precision[idx]), 4),
                "recall": round(float(recall[idx]), 4),
                "f1_score": round(float(f1[idx]), 4),
                "sample_count": int(support[idx])
            }

        # Karmaşıklık Matrisi (Confusion Matrix)
        cm = confusion_matrix(y_true, y_pred, labels=unique_labels)
        
        # Çıkarım Hızı (Throughput)
        total_samples = len(y_true)
        latency_per_sample_ms = (inference_time_seconds / total_samples) * 1000.0 if total_samples > 0 else 0.0
        throughput_logs_per_sec = total_samples / inference_time_seconds if inference_time_seconds > 0 else 0.0

        evaluation_summary = {
            "model_name": model_name,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "total_test_samples": total_samples,
            "overall_accuracy": round(float(accuracy), 4),
            "macro_averages": {
                "precision": round(float(macro_p), 4),
                "recall": round(float(macro_r), 4),
                "f1_score": round(float(macro_f1), 4)
            },
            "weighted_averages": {
                "precision": round(float(weighted_p), 4),
                "recall": round(float(weighted_r), 4),
                "f1_score": round(float(weighted_f1), 4)
            },
            "performance_benchmarks": {
                "total_inference_time_sec": round(inference_time_seconds, 4),
                "latency_per_log_ms": round(latency_per_sample_ms, 4),
                "throughput_logs_per_sec": round(throughput_logs_per_sec, 2)
            },
            "class_level_metrics": class_metrics,
            "confusion_matrix": cm.tolist(),
            "labels_order": unique_labels
        }

        return evaluation_summary

    def print_evaluation_report(self, eval_summary: Dict[str, Any]) -> None:
        """Değerlendirme sonuçlarını konsola profesyonel bir formatta yazdırır."""
        print("\n" + "=" * 95)
        print(f"📊 SIEM MODEL EVALUATION REPORT - [{eval_summary['model_name']}]")
        print("=" * 95)
        print(f"🎯 Toplam Test Örneği   : {eval_summary['total_test_samples']:,}")
        print(f"🏆 Genel Doğruluk (Acc)  : %{eval_summary['overall_accuracy'] * 100:.2f}")
        print(f"📈 Weighted F1-Score    : %{eval_summary['weighted_averages']['f1_score'] * 100:.2f}")
        print(f"⚡ Log Başı Çıkarım Hızı: {eval_summary['performance_benchmarks']['latency_per_log_ms']:.3f} ms")
        print(f"🚀 İşleme Kapasitesi    : {eval_summary['performance_benchmarks']['throughput_logs_per_sec']:,.2f} Log/Saniye")
        print("-" * 95)
        
        print(f"{'KATEGORİ':<25} | {'PRECISION':<10} | {'RECALL':<10} | {'F1-SCORE':<10} | {'SAYI':<8}")
        print("-" * 95)
        for label, metrics in eval_summary["class_level_metrics"].items():
            print(f"{label:<25} | %{metrics['precision']*100:<9.2f} | %{metrics['recall']*100:<9.2f} | %{metrics['f1_score']*100:<9.2f} | {metrics['sample_count']:<8}")
        print("=" * 95 + "\n")

    def plot_confusion_matrix(self, eval_summary: Dict[str, Any], save_path: str = None) -> None:
        """Confusion Matrix grafiğini çizer ve kaydeder."""
        cm = np.array(eval_summary["confusion_matrix"])
        labels = eval_summary["labels_order"]
        
        plt.figure(figsize=(10, 8))
        sns.heatmap(
            cm, annot=True, fmt="d", cmap="Blues", 
            xticklabels=labels, yticklabels=labels
        )
        plt.title(f"SIEM Confusion Matrix - {eval_summary['model_name']}", fontsize=14, fontweight="bold")
        plt.ylabel("Gerçek Etiket (True Label)", fontsize=11)
        plt.xlabel("Tahmin Edilen Etiket (Predicted Label)", fontsize=11)
        plt.xticks(rotation=45, ha="right")
        plt.tight_layout()

        output_file = save_path or os.path.join(config.paths.LOGS_DIR, "confusion_matrix.png")
        plt.savefig(output_file, dpi=300)
        plt.close()
        print(f"🖼️ Confusion Matrix grafiği kaydedildi: {output_file}")

    def export_json_report(self, eval_summary: Dict[str, Any], filepath: str = None) -> str:
        """Değerlendirme özetini JSON dosyası olarak dışa aktarır."""
        target_path = filepath or config.paths.EVALUATION_REPORT_FILE
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        
        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(eval_summary, f, indent=4, ensure_ascii=False)
            
        print(f"💾 JSON Değerlendirme Raporu Kaydedildi: {target_path}")
        return target_path


# Modül Testi
if __name__ == "__main__":
    y_true_sample = ["NETWORK_C2", "SYSTEM_INTEGRITY", "APPLICATION_EXPLOIT", "PROCESS_INJECTION", "SAFE_NOISE"] * 100
    y_pred_sample = ["NETWORK_C2", "SYSTEM_INTEGRITY", "APPLICATION_EXPLOIT", "PROCESS_INJECTION", "SAFE_NOISE"] * 98 + ["SYSTEM_INTEGRITY", "NETWORK_C2"] * 5
    
    evaluator = SIEMModelEvaluator()
    summary = evaluator.evaluate_predictions(y_true_sample, y_pred_sample, inference_time_seconds=0.045)
    evaluator.print_evaluation_report(summary)